﻿using System;

class PrintFirstLastName
{
    static void Main()
    {
        Console.WriteLine("Marko");
        Console.WriteLine("Totev");
    }
}