﻿using System;

class SquareRoot
{
    static void Main()
    {
        int n = 12345;
        double sqrt = Math.Sqrt(n);
        Console.WriteLine(sqrt);
    }
}