﻿using System;


class SquareRoot
{
    static void Main()
    {
        Console.WriteLine("The Square Root of 12345 is " + Math.Sqrt(12345));
    }
}