﻿using System;


class FirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Ivan");
        Console.WriteLine("Ivanov");
    }
}

