﻿using System;



class MainClass
{
    static void Main()
    {
        Point p = new Point();
        p.x = 10;
        p.y = 12;

        p.PrintPoint();
    }
}
